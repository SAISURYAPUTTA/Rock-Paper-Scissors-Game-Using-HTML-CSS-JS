# rps
A simple interactive rock paper scissor game using javascript and credits: clever programmer 
